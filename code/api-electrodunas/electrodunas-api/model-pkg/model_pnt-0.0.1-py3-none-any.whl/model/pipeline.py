from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler
from pyod.models.knn import KNN

from model.config.core import config
from model.processing import features as pp

pnt_pipe = Pipeline(
    [
        # Scaler
        ("scaler", MinMaxScaler()
         ),
        # KNN 
        ("K- Nearest Neighbors",
            KNN(
                method=config.model_config.method, 
                contamination=config.model_config.outliers_fraction,
            ),
        ),
    ]
)