import numpy as np
from config.core import config
from pipeline import pnt_pipe
from processing.data_manager import load_dataset, save_pipeline
from sklearn.model_selection import train_test_split


def run_training() -> None:
    """Train the model."""

    # read training data
    data = load_dataset(file_name=config.app_config.train_data_file)
    X = data[config.model_config.features]
    
    # fit model
    pnt_pipe.fit(X)

    # persist trained model
    save_pipeline(pipeline_to_persist=pnt_pipe)

if __name__ == "__main__":
    run_training()
